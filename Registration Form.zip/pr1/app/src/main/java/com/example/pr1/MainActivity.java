package com.example.pr1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.ArrayList;

import javax.xml.transform.Result;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private Switch switch_id;
    private RadioGroup radioGroup;
    private RadioButton male,female;
    private ToggleButton toggleButton;
    private Button submit;
    private CheckBox button1,button2,button3;
    private ArrayList<String> Result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        male=findViewById(R.id.Male);
        radioGroup=findViewById(R.id.radiogroup);
        female=findViewById(R.id.Female);
        switch_id=findViewById(R.id.switch1);
        button1=findViewById(R.id.Gearless);
        button2=findViewById(R.id.Geared);
        button3=findViewById(R.id.wheeler4);
        submit=findViewById(R.id.button4);
        Result = new ArrayList<>();
        toggleButton=findViewById(R.id.toggleButton);

        addListenerOnButtonClick();

        Spinner spinner = findViewById(R.id.spinner1);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.education, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        switch_id.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (switch_id.isChecked()) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                }
            }
        });



        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                if(male.isChecked()){
                    Toast.makeText(MainActivity.this, "Male", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "Female", Toast.LENGTH_SHORT).show();
                }
            }
        });

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(button1.isChecked())
                    Result.add("Gearless 2 wheeler");
                else
                    Result.remove("Gearless 2 wheeler");
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(button2.isChecked())
                    Result.add("Geared 2 wheeler");
                else
                    Result.remove("Geared 2 wheeler");
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(button3.isChecked())
                    Result.add("4 wheeler");
                else
                    Result.remove("4 wheeler");
            }
        });

    }

    public void addListenerOnButtonClick(){
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StringBuilder sb = new StringBuilder();
                sb.append("Working : ").append(toggleButton.getText());
                Toast.makeText(getApplicationContext(),sb.toString(),Toast.LENGTH_LONG).show();
            }
        });
    }

    public void openActivity(View v){
        Toast.makeText(this, "Web View", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this,MainActivity2.class);
        startActivity(intent);
    }

    public void openActivity1(View v){
        Toast.makeText(this, "Submitted", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this,MainActivity3.class);
        startActivity(intent);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}