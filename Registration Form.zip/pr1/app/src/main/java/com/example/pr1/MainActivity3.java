package com.example.pr1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.renderscript.ScriptGroup;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity3 extends AppCompatActivity {
    private EditText editText;
    private Button submit;
    private Button snack;
    private RatingBar ratingBar;
    private Button feedback;
    private CoordinatorLayout coordinatorLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        editText=findViewById(R.id.comment);
        submit=findViewById(R.id.button3);
        snack=findViewById(R.id.snackbar);
        coordinatorLayout=findViewById(R.id.coordinatorLayout);

        ratingBar=findViewById(R.id.ratingBar);
        coordinatorLayout=findViewById(R.id.coordinatorLayout);
        feedback=findViewById(R.id.feedback);
        submit=findViewById(R.id.button3);

        feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s = String.valueOf(ratingBar.getRating());
                Toast.makeText(getApplicationContext(),s + " Star",Toast.LENGTH_SHORT).show();
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = editText.getText().toString();
                if(text.isEmpty()){
                    alert("Please give a feedback");
                }else{
                    alert(text);
                }
            }
        });

        snack.setOnClickListener(View -> {
            Snackbar.make(coordinatorLayout,"Snackbar",Snackbar.LENGTH_INDEFINITE)
                    .setTextColor(Color.BLACK)
                    .setBackgroundTint(Color.YELLOW)
                    .setAction("Click Here",new android.view.View.OnClickListener() {
                        @Override
                        public void onClick(android.view.View v){
                            Toast.makeText(MainActivity3.this, "This is a Toast", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setActionTextColor(Color.BLACK)
                    .show();
        });
    }
    private void alert(String message){
            AlertDialog dlg= new AlertDialog.Builder(MainActivity3.this)
                    .setTitle("Comment")
                    .setMessage(message)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    })
                    .create();
            dlg.show();
        }
}