package com.example.frag1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {
    Button fragment1,fragment2,fragment3,fragment4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fragment1 = (Button) findViewById(R.id.button);
        fragment2 = (Button) findViewById(R.id.button2);
        fragment3 = (Button) findViewById(R.id.button3);
        fragment4 = (Button) findViewById(R.id.button4);
        listener();
    }
    public void listener(){
        fragment1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction f1 =
                        getSupportFragmentManager().beginTransaction();
                BlankFragment ff1=new BlankFragment();
                f1.replace(R.id.fragment_container,ff1);
                f1.commit();
            }
        });
        fragment2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                FragmentTransaction f2 =
                        getSupportFragmentManager().beginTransaction();
                BlankFragment2 ff2=new BlankFragment2();
                f2.replace(R.id.fragment_container,ff2);
                f2.commit();
            }
        });
        fragment3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                FragmentTransaction f3 =
                        getSupportFragmentManager().beginTransaction();
                BlankFragment3 ff3=new BlankFragment3();
                f3.replace(R.id.fragment_container,ff3);
                f3.commit();
            }
        });
        fragment4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                FragmentTransaction f4 =
                        getSupportFragmentManager().beginTransaction();
                BlankFragment4 ff4=new BlankFragment4();
                f4.replace(R.id.fragment_container,ff4);
                f4.commit();
            }
        });
    }
}