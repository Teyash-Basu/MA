package com.example.contactbook;

public class Contact {
    public int sno;
    public String name;
    public String phonenumber;

    Contact(int sno,String name,String phonenumber){
        this.sno = sno;
        this.name = name;
        this.phonenumber = phonenumber;
    }
}
